#!/usr/bin/env python3
"""Reproducer harness for a pyjwt token-validation vulnerability.

Reads a compact JWS token from the file given as argv[1] (default
/data/poc.bin) and decodes it with PyJWT, then reports whether the
installed jwt library accepted or rejected it.
"""
import sys

import jwt
from jwt.exceptions import InvalidTokenError

SECRET = "secret"


def main() -> int:
    poc_path = sys.argv[1] if len(sys.argv) > 1 else "/data/poc.bin"
    print(f"[run_poc] loading {poc_path}")
    with open(poc_path, "rb") as fh:
        token = fh.read().decode("ascii").strip()
    print(f"[run_poc] token: {token}")
    print("[run_poc] decoding with secret, algorithms=['HS256']")

    try:
        result = jwt.decode(token, SECRET, algorithms=["HS256"])
    except InvalidTokenError as exc:
        print(f"[run_poc] REJECTED: {exc}")
        print("[run_poc] SAFE: token was rejected")
        return 0

    print(f"[run_poc] ACCEPTED: {result}")
    print("[run_poc] VULNERABLE: token was accepted instead of rejected")
    return 1


if __name__ == "__main__":
    raise SystemExit(main())
