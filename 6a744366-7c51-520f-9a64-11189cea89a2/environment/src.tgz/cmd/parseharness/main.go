// Command parseharness parses one file with each of the project's stream
// parsers and reports what they made of it.
//
// Exit 2 is a usage or I/O error. Otherwise the process exits 0 once the
// parsers return, whatever they decided about the input.
package main

import (
	"fmt"
	"io"
	"os"
	"strings"

	"github.com/sigstore/rekor/pkg/types/alpine"
	"github.com/sigstore/rekor/pkg/types/helm"
)

var parsers = []struct {
	kind  string
	parse func(io.Reader) error
}{
	{"helm", func(r io.Reader) error { p := helm.Provenance{}; return p.Unmarshal(r) }},
	{"alpine", func(r io.Reader) error { p := alpine.Package{}; return p.Unmarshal(r) }},
}

func main() {
	if len(os.Args) < 2 {
		fmt.Fprintln(os.Stderr, "usage: parseharness <input>")
		os.Exit(2)
	}

	var refusals []string
	for _, parser := range parsers {
		f, err := os.Open(os.Args[1])
		if err != nil {
			fmt.Fprintf(os.Stderr, "open: %v\n", err)
			os.Exit(2)
		}
		err = parser.parse(f)
		_ = f.Close()
		if err == nil {
			fmt.Fprintln(os.Stderr, "accepted input")
			return
		}
		refusals = append(refusals, fmt.Sprintf("%s: %v", parser.kind, err))
	}
	fmt.Fprintf(os.Stderr, "rejected input: %s\n", strings.Join(refusals, "; "))
}
